// import PassVariableProps from '../../PassVariableProps'
import PassArrayProp from '../PassArrayProp'
import PassDataPropsCar from '../PassDataPropsCar'
import PassObjectProp from '../PassObjectProp'
// import AddInteraction_1 from './AddInteraction_1'
import './App.css'
import DrillingExample from './DrillingExample'
// import Assesments from './Assesments'
// import ColorPicker from './ColorPicker'
// import Counter from './Counter'
// import MultipleInputFeildForm from './MultipleInputFeildForm'

import RouterApp from './RouterApp'
// import Testing from './Testing'
// import Hook_useContext_Nested_PropDrilling from './Hook_useContext_Nested_PropDrilling'
// import Hook_useState_Update_State from './Hook_useState_Update_State'
// import Hook_useEffect_SetTimeOut from './Hook_useEffect_SetTimeOut'
// import Hook_useEffect_setTimeOut_withCleanUp from './Hook_useEffect_setTimeOut_withCleanUp'
// import EventHandler2 from './EventHandler2'
// import VariableObjectMapFilter from './VariableObjectMapFilter'
// import EventVariableArgument1 from './EventVariableArgument1'
// import EventVariableArgument from './EventVariableArgument'
// import ExternalCSS from './ExternalCSS'
// import Students from './Students'
// import List from './List'

// import UserGreeting from "./UserGreeting"

// import MyComponent from './MyComponent'
// import VariableObjectMaping from './VariableObjectMaping'
// import AddInteraction_1 from './AddInteraction_1' 

// import LogicANDOperator from './LogicANDOperator'
// import ComponentInheritance from './ComponentInheritance'
// import InputState from './InputState'
// import SharingStateBtwComponents from './SharingStateBtwComponents'
// import State_PropDrill from './State_PropDrill'
// import MultipleInputFeildForm from './MultipleInputFeildForm'
// import StateComponentMemory from './StateComponentMemory'
// import Hook_useEffect_setTimeOut_withCleanUp from './Hook_useEffect_setTimeOut_withCleanUp'
function App() {

  // const Vegetables=
  //       [{id:'1', name:' tomatoa', Calories:"189"},
  //       {id:'2', name:' Onion', Calories:"190"},
  //       {id:'3', name:' Cucumber', Calories:"80"},
  //       {id:'4', name:' Broccoli', Calories:"139"},
  //       {id:'5', name:' Seeweed', Calories:"1923"},
  //       {id:'6', name:' Green Onion', Calories:"194"}];

  //   const Fruit=
  //       [{id:'7', name:' Orange', Calories:"19"},
  //       {id:'8', name:' Banana', Calories:"196"},
  //       {id:'9', name:' Grape', Calories:"134"},
  //       {id:'10', name:'Orange', Calories:"124"},
  //       {id:'11', name:' Lemon', Calories:"156"},
  //       {id:'12', name:' Avocado', Calories:"129"}];

  return(
    <>
      {/* <MyComponent/> */}
      {/* <EventVariableArgument/> */}
      {/* <ExternalCSS/> */}
      {/* <VariableObjectMaping/> */}
      {/* <List Items={Vegetables}  Category="Veges"/>
      <List Items={Fruit}  Category="Fruits"/> */}
      {/* <EventVariableArgument1/> */}
      {/* <VariableObjectMapFilter/> */}
      {/* <EventHandler2/> */}
      {/* <AddInteraction_1/> */}
      {/* <ComponentInheritance/> */}
        {/* <LogicANDOperator/> */}
        {/* <InputState/> */}
        {/* <MultipleInputFeildForm/> */}
        {/* <Hook_useEffect_setTimeOut_withCleanUp/> */}
        {/* <Hook_useEffect_SetTimeOut/> */}
      {/* <Hook_useState_Update_State/> */}
      {/* <SharingStateBtwComponents/> */}
      {/* <Hook_useContext_Nested_PropDrilling/> */}
        {/* <Counter/> */}
        {/* <ColorPicker/> */}
      {/* <State_PropDrill/> */}
      <PassObjectProp/>
      <DrillingExample/>
      <PassDataPropsCar/>
      <PassArrayProp/>
      {/* <RouterApp/> */}
      {/* <Testing/> */}
      {/* <PassVariableProps/> */}
      {/* <Assesments/> */}
      {/* <AddInteraction_1/> */}
        {/* <StateComponentMemory/> */}
        {/* <MultipleInputFeildForm.jsx /> */}
    </>
    
  )
}

export default App

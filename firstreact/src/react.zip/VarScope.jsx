import React from 'react'

const VarScope = () => {
  var num1 = 20;
  let num2 = 30;

  for (let i= 0;  i <10; i++ )
    {
        return num1+num2;
    }
   
}

export default VarScopea


const EventHandler1 = () => {
  return (
    <>
    
    </>
  )
}

export default EventHandler1;
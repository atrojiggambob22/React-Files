import React from 'react'

//Always Create components with capital letters
 function hello() {
  return (
    <h1>Hello World</h1>
  )
}

export default hello

export const imageList =[
    {
        'id':'stanff01',
        'FirstName':'John',
        'LastName':'Mathias',
        'Position':'Faculty',
        'Gender':'Female',
        'Course':['Android','JSF','Web','SQL','Spring Boot']
    },
    {
        'id':'stanff02',
        'FirstName':'Mathias',
        'LastName':'Onyebuchi',
        'Position':'Student',
        'Gender':'Male',   
        'Course':['Android','JSF','Web','SQL','Spring Boot']
    },
    {
        'id':'stanff03',
        'FirstName':'John',
        'LastName':'Mathias',
        'Position':'Faculty',
        'Gender':'Female',
        'Course':['Android','JSF','Web','SQL','Spring Boot']
    },
    {
        'id':'stanff04',
        'FirstName':'John',
        'LastName':'Mathias',
        'Position':'Faculty',
        'Gender':'Female',
        'Course':['Android','JSF','Web','SQL','Spring Boot']
    }
]
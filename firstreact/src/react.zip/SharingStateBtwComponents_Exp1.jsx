import React from 'react'
import { useState } from 'react'



const SharingStateBtwComponents_Exp1 = () => {
  return (
    <div>SharingStateBtwComponents_Exp1</div>
  )
}

export default SharingStateBtwComponents_Exp1
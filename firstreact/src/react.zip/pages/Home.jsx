import React from 'react'

const Home = () => {
  return (
    <div>Home Niggas!!! </div>
  )
}

export default Home
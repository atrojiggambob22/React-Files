import React from 'react'

const Contact = () => {
  return (
    <div>Contact Me</div>
  )
}

export default Contact
import React from 'react'

const NoPage = () => {
  return (
    <div> Empty NoPage</div>
  )
}

export default NoPage
import React from 'react'

const Blogs = () => {
  return (
    <div>Blog Articles</div>
  )
}

export default Blogs